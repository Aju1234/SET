const firebaseConfig = {
  apiKey: "AIzaSyBjiARYz3BMrLLaaVGol71RL-XJTPxHsJc",
  authDomain: "connect-eb381.firebaseapp.com",
  projectId: "connect-eb381",
  storageBucket: "connect-eb381.appspot.com",
  messagingSenderId: "741406145319",
  appId: "1:741406145319:web:a3967996a60bf1ef3d4702"
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();


